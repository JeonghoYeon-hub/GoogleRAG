# 트러블슈팅 가이드

이 프로젝트를 다시 셋업하거나 유지보수할 때 흔히 마주치는 문제와 해결책 모음.

---

## 1. Google Drive OAuth 셋업

### 1-1. `client_secret.json` 타입은 반드시 **Web application**
- ❌ "Desktop app" (`{"installed": {...}}` 구조) → 리디렉션 URI 제약으로 인해 동작 안 함
- ✅ "Web application" (`{"web": {...}}` 구조) 필요

**발급 절차:**
1. [Google Cloud Console - Credentials](https://console.cloud.google.com/apis/credentials)
2. **+ CREATE CREDENTIALS** → **OAuth client ID**
3. Application type: **Web application**
4. Authorized redirect URIs에 정확히 다음을 등록:
   ```
   http://localhost:8000/auth/callback
   ```
5. JSON 다운로드 → 프로젝트 루트에 `client_secret.json`으로 저장
6. `.env`에 `GOOGLE_CLIENT_SECRET_FILE=client_secret.json` 설정

### 1-2. Google Drive API 활성화 필수
[APIs Library - Google Drive API](https://console.cloud.google.com/apis/library/drive.googleapis.com)에서 **Enable** 클릭. 안 하면 OAuth는 되는데 파일 목록 API에서 403이 떨어진다.

### 1-3. OAuth Consent Screen 설정
- Publishing status가 "Testing"이면 → **Test users**에 본인 Google 계정 추가
- Scopes에 `.../auth/drive.readonly` 추가

### 1-4. PKCE `code_verifier` 저장
`google-auth-oauthlib`이 `authorization_url()` 호출 시 자동으로 PKCE를 사용한다. 콜백에서 **새 Flow 객체를 만들면 `code_verifier`가 사라지므로** `invalid_grant: Missing code verifier` 에러가 발생한다.

**해결책:** state별로 `code_verifier`를 저장하고 콜백에서 주입.

```python
# auth-url 생성 시
auth_url, state = flow.authorization_url(access_type="offline", prompt="consent")
_oauth_states[state] = flow.code_verifier  # 저장

# callback에서
code_verifier = _oauth_states.pop(state, None)
flow = Flow.from_client_secrets_file(...)
flow.code_verifier = code_verifier  # 주입
flow.fetch_token(code=code)
```

---

## 2. Gemini File Search Store API

### 2-1. API 버전은 **v1beta** 사용
```python
genai.Client(api_key=..., http_options=types.HttpOptions(api_version="v1beta"))
```
- v1alpha는 Office MIME을 거부함
- 공식 문서 (`ai.google.dev/api/file-search/...`)도 v1beta 기준

### 2-2. **파일은 경로(str)로 넘길 것, IOBase 금지**
이게 DOCX/PPTX/XLSX 업로드 실패의 핵심 원인이었음.

```python
# ❌ 잘못: IOBase 사용 → SDK가 mime_type을 요청 body에 넣음 → 서버가 거부
with open(tmp_path, "rb") as f:
    client.file_search_stores.upload_to_file_search_store(
        file=f,  # IOBase
        config={"display_name": name, "mime_type": "application/vnd...."},
    )

# ✅ 올바름: 파일 경로 + config에 mime_type 미지정
client.file_search_stores.upload_to_file_search_store(
    file=tmp_path,  # str path
    config={"display_name": name},  # mime_type 빼기
)
```

**이유:** SDK는 mime_type을 두 곳에 보낸다.
- HTTP 헤더 `X-Goog-Upload-Header-Content-Type` (필수)
- 요청 body의 `mimeType` 필드 (선택)

Office 파일의 긴 MIME (`application/vnd.openxmlformats-officedocument...`)을 **body에 넣으면 400 INVALID_ARGUMENT** ("MIME type must be in a valid type/subtype format")가 떨어진다. 헤더는 OK.

파일 경로를 넘기면 SDK가 자동으로 `mimetypes.guess_type()`으로 검출해서 헤더에만 넣고 body는 건드리지 않는다.

IOBase를 넘기면 SDK가 mime_type을 요구하고, 우리가 명시하면 body에도 들어가서 거부당함.

---

## 3. FastAPI / 서버 운영

### 3-1. Windows 좀비 포트 점유
`Stop-Process`로 죽인 후에도 `netstat`에 LISTENING이 남아있는 경우가 있다. 새 서버가 정상 기동되어도 OS 라우팅이 좀비로 갈 수 있음.

**증상:** "여전히 같은 에러" — 사실은 새 서버 로그가 비어있고 좀비 서버가 응답하는 중.

**확인:**
```powershell
netstat -ano | findstr :8000
```
PID가 두 개 이상 LISTENING이면 좀비 있음.

**해결:**
```powershell
Get-Process python | Stop-Process -Force
# 몇 초 대기 후 재시작
```

### 3-2. uvicorn `--reload`가 적용 안 되는 경우
코드 변경 후 reload 로그가 안 보이면 수동 재시작.

---

## 4. 변수명 일관성 (구버전 코드 함정)

`app.py`에는 OAuth 관련 변수명이 한 번 헷갈렸던 적이 있다:
- `CLIENT_SECRET_FILE` (실제 정의됨)
- `GOOGLE_CLIENT_SECRET_FILE`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` (미정의 — 옛 코드 잔재)

콜백 / auth-url 엔드포인트 수정 시 미정의 변수 참조 안 하도록 주의. `Flow.from_client_secrets_file(CLIENT_SECRET_FILE, ...)`만 사용.

---

## 5. 프론트엔드 초기화 순서

`static/index.html`의 `init()` 함수에서:
- 서버 API 키가 환경변수로 설정된 경우 → 셋업 모달 스킵
- 이때 `initDrive()`를 같이 호출하지 않으면 Drive 버튼이 영원히 숨겨짐

```js
showApp();
await Promise.all([loadServers(), initDrive()]);  // initDrive 빼먹지 말 것
```

---

## 6. 데이터베이스 디버깅

업로드 실패 원인은 `sessions.db`의 `files` 테이블 `error` 컬럼에 저장된다. 빠른 조회:

```python
import sqlite3, time
conn = sqlite3.connect("sessions.db"); conn.row_factory = sqlite3.Row
for r in conn.execute("SELECT name, error, created_at, status FROM files ORDER BY created_at DESC LIMIT 10"):
    age = time.time() - r["created_at"]
    print(f"[{age:.0f}s ago] {r['status']:10s} {r['name'][:60]}")
    if r["error"]: print(f"    ERR: {r['error'][:300]}")
```

---

## 7. 지원 파일 형식

[공식 문서](https://ai.google.dev/gemini-api/docs/file-search?hl=ko#application) 기준:
- **Office:** DOCX, XLSX, PPTX, DOC, XLS (위 #2-2 방법으로 업로드 시)
- **PDF, TXT, HTML, MD, CSV, XML, JSON**
- **코드 파일:** Python, Java, JS/TS, C/C++ 등
- **ODT** (OpenDocument)

최대 파일 크기: 100MB (코드에서 강제)
